﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto3
{
    internal abstract class Reproductor
    {
        private string version;
        public string Version
        {
            get { return version; }
            set
            {
                if (value == "")
                {
                    throw new Exception("La versión no puede estar vacía");
                }
                else
                {
                    version = value;
                }
            }
        }
        public Reproductor(string version)
        {
            Version = version;
        }
        public abstract void Reproducir();
    }
} 

