﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto3
{
    internal class ReproductorPremium : Reproductor, IPausa, ICambioVelocidad
    {
        public string Pausa { get; set; }
        public int reproducirLento { get; set; }

        public int reproducirRapido { get; set; }

        public ReproductorPremium(string version) : base(version)
        {
            Version = version;
            Console.WriteLine($"Soy el reproductor premium con versión {version} y esto es lo que reproduzco:\r\nBang\r\nBang\r\nBang\r\nBang");
        }

        public void Reproducir(int cancion)
        {
            Console.WriteLine($"Soy la cancíon número {cancion}");
        }
        public static void Pausar(string pausa)
        {
            Console.WriteLine($"Soy el reproductor premium con version v.2.0.0 y he pausado la reproducción en el instante {pausa}");
        }
        public void Reanudar()
        {
            Console.WriteLine("Soy el reproductor premium con version v.2.0.0 y he reanudado la reproducción");
        }
        public void ReproducirLento(int lento)
        {
            Console.WriteLine($"Soy el reproductor premium con version v.2.0.0 y reduzco la velocidad {lento} veces");
        }
        public void ReproducirRapido(int rapido)
        {
            Console.WriteLine($"Soy el reproductor premium con version v.2.0.0 y aumento la velocidad {rapido} veces");
        }

        public override void Reproducir()
        {
            throw new NotImplementedException();
        }
    }
}
