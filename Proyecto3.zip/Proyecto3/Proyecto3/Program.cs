﻿using Proyecto3;

var reproductorBasico = new ReproductorBasico("v.1.0.0");
var reproductorPremium = new ReproductorPremium("v.2.0.0");

reproductorBasico.Reproducir(2);
reproductorPremium.Reproducir(4);

reproductorBasico.Pausar("1:05");
reproductorBasico.Reanudar();
ReproductorPremium.Pausar("0:58");
reproductorPremium.Reanudar();

reproductorPremium.ReproducirLento(2);
reproductorPremium.ReproducirRapido(3);