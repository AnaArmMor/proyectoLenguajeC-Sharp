﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto3
{
    internal interface ICambioVelocidad
    {
        public int reproducirLento { get; set; }

        public int reproducirRapido { get; set; }
    }
}
