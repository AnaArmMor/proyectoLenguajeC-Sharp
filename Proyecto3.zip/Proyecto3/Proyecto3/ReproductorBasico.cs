﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto3
{
    internal class ReproductorBasico : Reproductor, ICambioVelocidad
    {
        public int reproducirLento { get; set; }

        public int reproducirRapido { get; set; }
        public ReproductorBasico(string version) : base(version)
        {
            Version = version;
            Console.WriteLine($"Soy el reproductor básico con versión {version} y esto es lo que reproduzco:\r\nBang\r\nBang");
        }

        public void Reproducir(int cancion)
        {
            Console.WriteLine($"Soy la cancíon número {cancion}");
        }
        public void Pausar(string pausa)
        {
            Console.WriteLine($"Soy el reproductor básico con versión v.1.0.0 y he pausado la reproducción en el instante {pausa}");
        }
        public void Reanudar()
        {
            Console.WriteLine("Soy el reproductor básico con version v.1.0.0 y he reanudado la reproducción");
        }

        public override void Reproducir()
        {
            throw new NotImplementedException();
        }
    }

}