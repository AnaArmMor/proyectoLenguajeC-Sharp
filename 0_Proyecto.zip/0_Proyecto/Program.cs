﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
//Problema 1//
int contador = 0;
Console.WriteLine(contador);

//Problema 2//
double ahorros = 1535.45;
Console.WriteLine("double ahorros");

//Problema 3//
bool esEspanol = true;
Console.WriteLine(esEspanol);

//Problema 4//
char inicial = 'G';
Console.WriteLine(inicial);

//Problema 5 se trata de un array y no se le puede hacer console.writeLine porque los arrays deben llevar una especifica codificacion//
double[] temperaturas = new double[] { 25.5, 31.1, 28.0, 26.3 };
//Console.WriteLine(temperaturas); OJO NO SE PUEDE IMPRIMIR POR CONSOLA ASI, HAY QUE UNSAR UN BUCLE//
for (int i = 0; i < temperaturas.Length; i++)
{
    Console.WriteLine(temperaturas[i]);
}

foreach (var temperatura in temperaturas)
{
    Console.WriteLine(temperatura);
}




