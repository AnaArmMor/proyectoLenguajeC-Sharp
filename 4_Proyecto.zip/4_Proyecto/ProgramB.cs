﻿// Actividad 24//
//Problema 1//
using System;

string firstName = "Javier ";
string lastName = "Gonzalez";
Console.WriteLine("Introduce tu primer nombre y tu primer apellido");
Console.WriteLine(firstName + lastName);
Console.WriteLine(firstName[6]);

//Problema 2//
string firstName1 = "Javier ";
string lastName1 = "Gonzalez";
Console.WriteLine("Introduce tu primer nombre y tu primer apellido separados por un espacio");
Console.WriteLine(firstName1 + lastName1);
Console.WriteLine("Tu nombre es " + firstName1);
Console.WriteLine("Tu apellido es " + lastName1);

//Problema 3//
string firstName2 = "Javier";
string lastName2 = "Gonzalez";
Console.WriteLine("Introduce tu primer nombre y tu primer apellido separados por un espacio");
Console.WriteLine(firstName2 + lastName2);
string result = firstName.ToUpper();
string result1 = lastName.ToUpper();
Console.WriteLine("Tu nombre es " + result);
Console.WriteLine("Tu apellido es " + result1);

//Problema 4//

var texto = "Hola soy yo";
//var textoLargo = "Un dia tal como hoy, estaba yo en la Mancha caminando sobre el asfalto mojado y vi de lejos como se acercaba ese tunante"

int ContarEspacios(string cadena)
{
    return cadena.Count(Char.IsWhiteSpace);
}
Console.WriteLine(ContarEspacios(texto));

// Problema 5//

int ContarCoincidenciasde(string texto);
{
    var separaciones = texto.Split(" de ");
    return separaciones.Length - 1;
}
Console.WriteLine("Apariciones 'de':" + ContarCoincidenciasDe(texto));



